
  # IELTS Learning Website

  This is a code bundle for IELTS Learning Website. The original project is available at https://www.figma.com/design/FTcTPkUnmHYKaM6uRGVD83/IELTS-Learning-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  