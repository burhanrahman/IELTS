import { useState } from 'react';
import { HomePage } from './components/HomePage';
import { TestInterface } from './components/TestInterface';
import { ResultsPage } from './components/ResultsPage';
import { getRandomTestSet } from './data/questionBank';
import type { ReadingPassage, ListeningSection, WritingTask, SpeakingPart } from './data/questionBank';

export type TestAnswers = {
  reading: Record<string, string>;
  listening: Record<string, string>;
  writing: Record<string, string>;
  speaking: Record<string, string>;
};

export type TestResults = {
  reading: { score: number; total: number; band: number };
  listening: { score: number; total: number; band: number };
  writing: { score: number; total: number; band: number };
  speaking: { score: number; total: number; band: number };
  overall: number;
};

export type TestSet = {
  reading: ReadingPassage[];
  listening: ListeningSection[];
  writing: WritingTask[];
  speaking: SpeakingPart[];
  testId: string;
};

export default function App() {
  const [currentPage, setCurrentPage] = useState<'home' | 'test' | 'results'>('home');
  const [testResults, setTestResults] = useState<TestResults | null>(null);
  const [currentTestSet, setCurrentTestSet] = useState<TestSet | null>(null);
  const [correctAnswers, setCorrectAnswers] = useState<Record<string, string>>({});

  const startTest = () => {
    // Generate a new random test set each time
    const newTestSet = getRandomTestSet();
    setCurrentTestSet(newTestSet);
    
    // Build correct answers map from the test set
    const answers: Record<string, string> = {};
    newTestSet.reading.forEach(passage => {
      passage.questions.forEach(q => {
        answers[q.id] = q.correctAnswer;
      });
    });
    newTestSet.listening.forEach(section => {
      section.questions.forEach(q => {
        answers[q.id] = q.correctAnswer;
      });
    });
    setCorrectAnswers(answers);
    
    setCurrentPage('test');
    setTestResults(null);
  };

  const submitTest = (answers: TestAnswers) => {
    const results = calculateResults(answers, correctAnswers, currentTestSet!);
    setTestResults(results);
    setCurrentPage('results');
  };

  const goHome = () => {
    setCurrentPage('home');
    setTestResults(null);
    setCurrentTestSet(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
      {currentPage === 'home' && <HomePage onStartTest={startTest} />}
      {currentPage === 'test' && currentTestSet && (
        <TestInterface 
          testSet={currentTestSet}
          onSubmit={submitTest} 
          onCancel={goHome} 
        />
      )}
      {currentPage === 'results' && testResults && (
        <ResultsPage results={testResults} onRetakeTest={startTest} onGoHome={goHome} />
      )}
    </div>
  );
}

function calculateResults(
  answers: TestAnswers, 
  correctAnswers: Record<string, string>,
  testSet: TestSet
): TestResults {
  // Calculate reading score
  const totalReadingQuestions = testSet.reading.reduce((sum, passage) => sum + passage.questions.length, 0);
  const readingScore = Object.keys(answers.reading).filter(
    (key) => answers.reading[key] === correctAnswers[key]
  ).length;

  // Calculate listening score
  const totalListeningQuestions = testSet.listening.reduce((sum, section) => sum + section.questions.length, 0);
  const listeningScore = Object.keys(answers.listening).filter(
    (key) => answers.listening[key] === correctAnswers[key]
  ).length;

  // Band score conversion matching real IELTS (for 10 questions, simplified for demo)
  const convertToBand = (score: number, total: number): number => {
    const percentage = score / total;
    if (percentage >= 0.9) return 9;
    if (percentage >= 0.8) return 8;
    if (percentage >= 0.7) return 7;
    if (percentage >= 0.6) return 6.5;
    if (percentage >= 0.5) return 6;
    if (percentage >= 0.4) return 5.5;
    if (percentage >= 0.3) return 5;
    if (percentage >= 0.2) return 4.5;
    return 4;
  };

  // For writing and speaking, estimate scores based on completion and length
  const writingScore = testSet.writing.filter((task, index) => {
    const key = task.id;
    const response = answers.writing[key];
    if (!response) return false;
    const wordCount = response.split(/\s+/).filter(Boolean).length;
    return wordCount >= task.minWords * 0.6; // At least 60% of minimum words
  }).length;

  const speakingScore = testSet.speaking.filter((part, index) => {
    const key = part.id;
    const response = answers.speaking[key];
    if (!response) return false;
    const wordCount = response.split(/\s+/).filter(Boolean).length;
    return wordCount >= 30; // Minimum viable response
  }).length;

  const readingBand = convertToBand(readingScore, totalReadingQuestions);
  const listeningBand = convertToBand(listeningScore, totalListeningQuestions);
  const writingBand = convertToBand(writingScore, testSet.writing.length);
  const speakingBand = convertToBand(speakingScore, testSet.speaking.length);

  const overall = Math.round((readingBand + listeningBand + writingBand + speakingBand) / 4 * 2) / 2;

  return {
    reading: { score: readingScore, total: totalReadingQuestions, band: readingBand },
    listening: { score: listeningScore, total: totalListeningQuestions, band: listeningBand },
    writing: { score: writingScore, total: testSet.writing.length, band: writingBand },
    speaking: { score: speakingScore, total: testSet.speaking.length, band: speakingBand },
    overall,
  };
}
