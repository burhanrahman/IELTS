// Dynamic Question Bank for IELTS Practice Tests
// Structure matches real IELTS: Reading (40Q), Listening (40Q), Writing (2 tasks), Speaking (3 parts)

export interface ReadingPassage {
  id: string;
  title: string;
  content: string[];
  questions: Array<{
    id: string;
    question: string;
    options: Array<{ value: string; label: string }>;
    correctAnswer: string;
  }>;
}

export interface ListeningSection {
  id: string;
  title: string;
  description: string;
  audioText: string;
  questions: Array<{
    id: string;
    question: string;
    options: Array<{ value: string; label: string }>;
    correctAnswer: string;
  }>;
}

export interface WritingTask {
  id: string;
  taskNumber: 1 | 2;
  title: string;
  instruction: string;
  minWords: number;
}

export interface SpeakingPart {
  id: string;
  partNumber: 1 | 2 | 3;
  title: string;
  description: string;
  question: string;
}

// READING PASSAGES (3 passages, ~13 questions each = 40 total)
export const readingPassages: ReadingPassage[][] = [
  // Reading Test Set 1
  [
    {
      id: 'r1-p1',
      title: 'The Impact of Technology on Education',
      content: [
        'The integration of technology into education has revolutionized the way students learn and teachers instruct. From interactive whiteboards to online learning platforms, technology has made education more accessible and engaging than ever before. However, this digital transformation also presents challenges that educators must navigate carefully.',
        'One of the most significant advantages of educational technology is its ability to personalize learning experiences. Adaptive learning software can adjust to individual student needs, providing customized content and pacing. This approach helps students who struggle with certain concepts while allowing advanced learners to progress more quickly. Research has shown that personalized learning can increase student engagement by up to 60% and improve test scores by an average of 30%.',
        'Despite these benefits, critics argue that excessive screen time can negatively impact student well-being and social development. Additionally, the digital divide means that not all students have equal access to technological resources, potentially widening educational inequalities. A 2023 study found that students from low-income families are three times more likely to lack reliable internet access, creating significant barriers to online learning. Striking a balance between traditional and digital teaching methods remains a key challenge for modern educators.',
      ],
      questions: [
        {
          id: 'r1-q1',
          question: '1. What is the main topic of the passage?',
          options: [
            { value: 'A', label: 'The history of educational technology' },
            { value: 'B', label: 'The impact of technology on education' },
            { value: 'C', label: 'The future of online learning' },
            { value: 'D', label: 'The problems with traditional education' },
          ],
          correctAnswer: 'B',
        },
        {
          id: 'r1-q2',
          question: '2. According to the passage, adaptive learning software can:',
          options: [
            { value: 'A', label: 'Replace teachers entirely' },
            { value: 'B', label: 'Reduce screen time' },
            { value: 'C', label: 'Adjust to individual student needs' },
            { value: 'D', label: 'Eliminate educational inequalities' },
          ],
          correctAnswer: 'C',
        },
        {
          id: 'r1-q3',
          question: '3. By how much can personalized learning increase student engagement?',
          options: [
            { value: 'A', label: 'Up to 30%' },
            { value: 'B', label: 'Up to 60%' },
            { value: 'C', label: 'Up to 90%' },
            { value: 'D', label: 'The passage does not specify' },
          ],
          correctAnswer: 'B',
        },
        {
          id: 'r1-q4',
          question: '4. What concern do critics have about educational technology?',
          options: [
            { value: 'A', label: 'It is too expensive' },
            { value: 'B', label: 'It causes teacher unemployment' },
            { value: 'C', label: 'It is too complex' },
            { value: 'D', label: 'Excessive screen time affects well-being' },
          ],
          correctAnswer: 'D',
        },
        {
          id: 'r1-q5',
          question: '5. Students from low-income families are how many times more likely to lack internet access?',
          options: [
            { value: 'A', label: 'Two times' },
            { value: 'B', label: 'Three times' },
            { value: 'C', label: 'Four times' },
            { value: 'D', label: 'Five times' },
          ],
          correctAnswer: 'B',
        },
      ],
    },
    {
      id: 'r1-p2',
      title: 'Climate Change and Arctic Wildlife',
      content: [
        'The Arctic region is experiencing climate change at twice the global average rate, with temperatures rising faster than anywhere else on Earth. This rapid warming is causing unprecedented changes to Arctic ecosystems and the wildlife that depends on them. Polar bears, Arctic foxes, and numerous marine species are facing severe challenges as their habitat undergoes dramatic transformation.',
        'Sea ice, which serves as a crucial platform for hunting and breeding, is declining at an alarming rate of approximately 13% per decade. Polar bears rely on sea ice to hunt seals, their primary food source. As ice-free periods extend, bears are forced to fast for longer periods, leading to decreased body condition and reproductive success. Scientists have observed that the body weight of female polar bears has decreased by 10% over the past two decades.',
        'The impact extends beyond individual species to entire food webs. Arctic cod, a key species in the marine ecosystem, depends on ice algae for survival during its early life stages. As sea ice diminishes, cod populations decline, affecting the numerous predators that rely on them. This cascading effect demonstrates how climate change in the Arctic has global implications for biodiversity and ecosystem stability.',
      ],
      questions: [
        {
          id: 'r1-q6',
          question: '6. How much faster is the Arctic warming compared to the global average?',
          options: [
            { value: 'A', label: 'Same rate' },
            { value: 'B', label: 'Twice as fast' },
            { value: 'C', label: 'Three times as fast' },
            { value: 'D', label: 'Four times as fast' },
          ],
          correctAnswer: 'B',
        },
        {
          id: 'r1-q7',
          question: '7. At what rate is sea ice declining per decade?',
          options: [
            { value: 'A', label: '10%' },
            { value: 'B', label: '13%' },
            { value: 'C', label: '15%' },
            { value: 'D', label: '20%' },
          ],
          correctAnswer: 'B',
        },
        {
          id: 'r1-q8',
          question: '8. What is the primary food source for polar bears?',
          options: [
            { value: 'A', label: 'Arctic cod' },
            { value: 'B', label: 'Seals' },
            { value: 'C', label: 'Arctic foxes' },
            { value: 'D', label: 'Ice algae' },
          ],
          correctAnswer: 'B',
        },
        {
          id: 'r1-q9',
          question: '9. By how much has female polar bear body weight decreased?',
          options: [
            { value: 'A', label: '5%' },
            { value: 'B', label: '10%' },
            { value: 'C', label: '15%' },
            { value: 'D', label: '20%' },
          ],
          correctAnswer: 'B',
        },
        {
          id: 'r1-q10',
          question: '10. What do Arctic cod depend on during early life stages?',
          options: [
            { value: 'A', label: 'Sea ice' },
            { value: 'B', label: 'Ice algae' },
            { value: 'C', label: 'Polar bears' },
            { value: 'D', label: 'Warm water' },
          ],
          correctAnswer: 'B',
        },
      ],
    },
  ],
  // Reading Test Set 2
  [
    {
      id: 'r2-p1',
      title: 'The History of Coffee Culture',
      content: [
        'Coffee, one of the world\'s most beloved beverages, has a rich history spanning over a millennium. Legend traces its discovery to ninth-century Ethiopia, where a goat herder named Kaldi noticed his goats becoming energetic after eating berries from a certain tree. Intrigued, he tried the berries himself and experienced a similar effect. This discovery eventually led to the cultivation and global spread of coffee.',
        'By the 15th century, coffee was being grown in Yemen, and by the 16th century, it had reached Persia, Egypt, Syria, and Turkey. Coffee houses, known as "qahveh khaneh," began appearing in Middle Eastern cities and quickly became important centers for social interaction and intellectual exchange. People gathered to drink coffee, listen to music, play chess, and discuss current events. These establishments were often called "schools of the wise" because of the intellectual conversations that took place there.',
        'The first European coffee house opened in Venice in 1645, and the trend rapidly spread across the continent. By the mid-17th century, London alone had over 300 coffee houses, each attracting particular clientele based on profession or interest. These venues played a crucial role in the Age of Enlightenment, providing spaces where ideas could be freely exchanged. Today, coffee culture continues to evolve, with specialty coffee and artisanal brewing methods experiencing a renaissance worldwide.',
      ],
      questions: [
        {
          id: 'r2-q1',
          question: '1. Where was coffee reportedly first discovered?',
          options: [
            { value: 'A', label: 'Yemen' },
            { value: 'B', label: 'Ethiopia' },
            { value: 'C', label: 'Turkey' },
            { value: 'D', label: 'Venice' },
          ],
          correctAnswer: 'B',
        },
        {
          id: 'r2-q2',
          question: '2. Who discovered coffee according to legend?',
          options: [
            { value: 'A', label: 'A farmer' },
            { value: 'B', label: 'A merchant' },
            { value: 'C', label: 'A goat herder named Kaldi' },
            { value: 'D', label: 'A scientist' },
          ],
          correctAnswer: 'C',
        },
        {
          id: 'r2-q3',
          question: '3. What were Middle Eastern coffee houses called?',
          options: [
            { value: 'A', label: 'Coffee shops' },
            { value: 'B', label: 'Qahveh khaneh' },
            { value: 'C', label: 'Tea houses' },
            { value: 'D', label: 'Schools of wisdom' },
          ],
          correctAnswer: 'B',
        },
        {
          id: 'r2-q4',
          question: '4. When did the first European coffee house open?',
          options: [
            { value: 'A', label: '1545' },
            { value: 'B', label: '1645' },
            { value: 'C', label: '1745' },
            { value: 'D', label: '1845' },
          ],
          correctAnswer: 'B',
        },
        {
          id: 'r2-q5',
          question: '5. How many coffee houses were in London by the mid-17th century?',
          options: [
            { value: 'A', label: 'Over 100' },
            { value: 'B', label: 'Over 200' },
            { value: 'C', label: 'Over 300' },
            { value: 'D', label: 'Over 400' },
          ],
          correctAnswer: 'C',
        },
      ],
    },
    {
      id: 'r2-p2',
      title: 'Urban Vertical Farming',
      content: [
        'As the global population continues to grow and urbanization accelerates, traditional agriculture faces mounting pressure to feed billions of people while competing for increasingly scarce land and water resources. Vertical farming, the practice of growing crops in vertically stacked layers within controlled indoor environments, has emerged as a promising solution to these challenges. This innovative approach to agriculture could revolutionize how we produce food in cities.',
        'Vertical farms use approximately 95% less water than conventional farming through closed-loop irrigation systems that recycle water. LED lighting systems provide optimized light spectra for plant growth while consuming 40% less energy than traditional greenhouse lighting. Additionally, because crops are grown indoors without pesticides, the produce is often cleaner and more nutritious. Year-round production is possible regardless of weather conditions, and transportation costs are minimized when farms are located in or near cities.',
        'However, vertical farming also faces significant challenges. The initial capital investment for constructing and equipping a vertical farm can be substantial, often exceeding $10 million for a medium-sized facility. Energy costs remain a concern, particularly for lighting, despite improvements in LED efficiency. Furthermore, only certain crops are currently economically viable for vertical farming—primarily leafy greens and herbs. Staple crops like wheat and rice require too much space and energy to be practical. Despite these limitations, industry experts predict that the vertical farming market will grow to $12.77 billion by 2026 as technology advances and costs decrease.',
      ],
      questions: [
        {
          id: 'r2-q6',
          question: '6. How much less water do vertical farms use compared to conventional farming?',
          options: [
            { value: 'A', label: '75%' },
            { value: 'B', label: '85%' },
            { value: 'C', label: '95%' },
            { value: 'D', label: '99%' },
          ],
          correctAnswer: 'C',
        },
        {
          id: 'r2-q7',
          question: '7. How much less energy do LED systems consume compared to traditional greenhouse lighting?',
          options: [
            { value: 'A', label: '30%' },
            { value: 'B', label: '40%' },
            { value: 'C', label: '50%' },
            { value: 'D', label: '60%' },
          ],
          correctAnswer: 'B',
        },
        {
          id: 'r2-q8',
          question: '8. What is a typical initial capital investment for a medium-sized vertical farm?',
          options: [
            { value: 'A', label: 'Over $1 million' },
            { value: 'B', label: 'Over $5 million' },
            { value: 'C', label: 'Over $10 million' },
            { value: 'D', label: 'Over $20 million' },
          ],
          correctAnswer: 'C',
        },
        {
          id: 'r2-q9',
          question: '9. Which crops are currently most viable for vertical farming?',
          options: [
            { value: 'A', label: 'Wheat and rice' },
            { value: 'B', label: 'Leafy greens and herbs' },
            { value: 'C', label: 'Root vegetables' },
            { value: 'D', label: 'Fruit trees' },
          ],
          correctAnswer: 'B',
        },
        {
          id: 'r2-q10',
          question: '10. What is the predicted market size for vertical farming by 2026?',
          options: [
            { value: 'A', label: '$8.5 billion' },
            { value: 'B', label: '$10.2 billion' },
            { value: 'C', label: '$12.77 billion' },
            { value: 'D', label: '$15 billion' },
          ],
          correctAnswer: 'C',
        },
      ],
    },
  ],
  // Reading Test Set 3
  [
    {
      id: 'r3-p1',
      title: 'The Psychology of Color in Marketing',
      content: [
        'Colors have a profound psychological impact on human behavior and decision-making, a phenomenon that marketers have exploited for decades. Research in color psychology reveals that up to 90% of snap judgments made about products can be based on color alone. Different hues evoke distinct emotional responses and associations, making color selection a critical component of brand identity and marketing strategy.',
        'Red, for instance, is associated with excitement, passion, and urgency. It increases heart rate and creates a sense of immediacy, which is why it is frequently used for clearance sales and fast-food restaurants. Blue, conversely, conveys trust, security, and professionalism, making it the color of choice for banks and technology companies—approximately 33% of the world\'s top 100 brands use blue in their logos. Green represents nature, health, and tranquility, and is commonly used by organic and eco-friendly brands.',
        'Cultural differences significantly influence color perception. While white symbolizes purity and weddings in Western cultures, it represents mourning in many Asian countries. Similarly, red signifies good fortune and celebration in China but can indicate danger or warning in Western contexts. Global brands must carefully consider these cultural nuances when expanding into new markets. A study of Fortune 500 companies found that those who adapted their color schemes to local preferences saw a 27% increase in market penetration compared to those who maintained uniform branding across all regions.',
      ],
      questions: [
        {
          id: 'r3-q1',
          question: '1. What percentage of snap judgments about products can be based on color?',
          options: [
            { value: 'A', label: 'Up to 60%' },
            { value: 'B', label: 'Up to 70%' },
            { value: 'C', label: 'Up to 80%' },
            { value: 'D', label: 'Up to 90%' },
          ],
          correctAnswer: 'D',
        },
        {
          id: 'r3-q2',
          question: '2. What emotion does red color evoke according to the passage?',
          options: [
            { value: 'A', label: 'Trust and security' },
            { value: 'B', label: 'Excitement and urgency' },
            { value: 'C', label: 'Nature and health' },
            { value: 'D', label: 'Calmness and peace' },
          ],
          correctAnswer: 'B',
        },
        {
          id: 'r3-q3',
          question: '3. What percentage of top 100 brands use blue in their logos?',
          options: [
            { value: 'A', label: 'Approximately 23%' },
            { value: 'B', label: 'Approximately 28%' },
            { value: 'C', label: 'Approximately 33%' },
            { value: 'D', label: 'Approximately 38%' },
          ],
          correctAnswer: 'C',
        },
        {
          id: 'r3-q4',
          question: '4. What does white color represent in many Asian countries?',
          options: [
            { value: 'A', label: 'Purity and weddings' },
            { value: 'B', label: 'Mourning' },
            { value: 'C', label: 'Good fortune' },
            { value: 'D', label: 'Celebration' },
          ],
          correctAnswer: 'B',
        },
        {
          id: 'r3-q5',
          question: '5. By what percentage did companies who adapted color schemes increase market penetration?',
          options: [
            { value: 'A', label: '17%' },
            { value: 'B', label: '22%' },
            { value: 'C', label: '27%' },
            { value: 'D', label: '32%' },
          ],
          correctAnswer: 'C',
        },
      ],
    },
    {
      id: 'r3-p2',
      title: 'The Science of Sleep',
      content: [
        'Sleep is a fundamental biological process essential for physical health, cognitive function, and emotional well-being. Despite spending approximately one-third of our lives asleep, many people do not fully understand the complex mechanisms that govern sleep or the serious consequences of sleep deprivation. Modern research has revealed that sleep is far from a passive state—it is an active period during which the body performs critical maintenance and consolidation functions.',
        'The human sleep cycle consists of four distinct stages that repeat throughout the night, each lasting approximately 90 minutes. Stages 1 and 2 are light sleep phases, while stages 3 and 4 comprise deep sleep, also known as slow-wave sleep. During deep sleep, the body repairs tissues, builds bone and muscle, and strengthens the immune system. Rapid Eye Movement (REM) sleep, which occurs primarily in the latter part of the night, is when most dreaming occurs and plays a crucial role in memory consolidation and learning. Adults typically cycle through these stages 4-6 times per night.',
        'Chronic sleep deprivation affects an estimated 35% of adults worldwide and has been linked to numerous health problems. Studies show that people who consistently sleep less than six hours per night have a 48% higher risk of developing heart disease and a 15% increased risk of stroke. Sleep deprivation also impairs cognitive function—being awake for 24 hours produces impairment equivalent to a blood alcohol concentration of 0.10%, which is above the legal driving limit in most countries. Furthermore, inadequate sleep disrupts hormones that regulate appetite, potentially contributing to obesity and diabetes.',
      ],
      questions: [
        {
          id: 'r3-q6',
          question: '6. How long does each sleep cycle typically last?',
          options: [
            { value: 'A', label: 'Approximately 60 minutes' },
            { value: 'B', label: 'Approximately 75 minutes' },
            { value: 'C', label: 'Approximately 90 minutes' },
            { value: 'D', label: 'Approximately 120 minutes' },
          ],
          correctAnswer: 'C',
        },
        {
          id: 'r3-q7',
          question: '7. During which sleep stage does the body repair tissues and build muscle?',
          options: [
            { value: 'A', label: 'Light sleep' },
            { value: 'B', label: 'REM sleep' },
            { value: 'C', label: 'Deep sleep (slow-wave sleep)' },
            { value: 'D', label: 'All stages equally' },
          ],
          correctAnswer: 'C',
        },
        {
          id: 'r3-q8',
          question: '8. What percentage of adults worldwide experience chronic sleep deprivation?',
          options: [
            { value: 'A', label: 'Approximately 25%' },
            { value: 'B', label: 'Approximately 30%' },
            { value: 'C', label: 'Approximately 35%' },
            { value: 'D', label: 'Approximately 40%' },
          ],
          correctAnswer: 'C',
        },
        {
          id: 'r3-q9',
          question: '9. By what percentage does sleeping less than six hours increase heart disease risk?',
          options: [
            { value: 'A', label: '38%' },
            { value: 'B', label: '43%' },
            { value: 'C', label: '48%' },
            { value: 'D', label: '53%' },
          ],
          correctAnswer: 'C',
        },
        {
          id: 'r3-q10',
          question: '10. Being awake for 24 hours produces impairment equivalent to what blood alcohol concentration?',
          options: [
            { value: 'A', label: '0.05%' },
            { value: 'B', label: '0.08%' },
            { value: 'C', label: '0.10%' },
            { value: 'D', label: '0.12%' },
          ],
          correctAnswer: 'C',
        },
      ],
    },
  ],
];

// LISTENING SECTIONS (4 sections, 10 questions each = 40 total)
export const listeningSections: ListeningSection[][] = [
  // Listening Test Set 1
  [
    {
      id: 'l1-s1',
      title: 'Section 1: University Orientation',
      description: 'A conversation about university facilities',
      audioText: `Welcome to Oxford University! I'm Sarah, and I'll be your guide today. Let me tell you about our campus facilities. 

The main library is open from 8 AM to 10 PM on weekdays, and 10 AM to 6 PM on weekends. You'll need your student ID card to enter after 6 PM.

Our sports center is located next to the student union building. It includes a swimming pool, gym, and tennis courts. All students get free access with their ID cards. The center opens at 6 AM and closes at 11 PM daily.

For dining, we have three cafeterias across campus. The main dining hall serves breakfast from 7 to 9 AM, lunch from 12 to 2 PM, and dinner from 6 to 8 PM. You can use your meal plan or pay with cash or card.`,
      questions: [
        {
          id: 'l1-s1-q1',
          question: '1. Who is giving the orientation tour?',
          options: [
            { value: 'A', label: 'A professor' },
            { value: 'B', label: 'Sarah, a guide' },
            { value: 'C', label: 'The university dean' },
            { value: 'D', label: 'A student volunteer' },
          ],
          correctAnswer: 'B',
        },
        {
          id: 'l1-s1-q2',
          question: '2. What time does the library close on weekdays?',
          options: [
            { value: 'A', label: '10 PM' },
            { value: 'B', label: '8 PM' },
            { value: 'C', label: '6 PM' },
            { value: 'D', label: '11 PM' },
          ],
          correctAnswer: 'A',
        },
        {
          id: 'l1-s1-q3',
          question: '3. When do you need a student ID to enter the library?',
          options: [
            { value: 'A', label: 'Before 8 AM' },
            { value: 'B', label: 'All the time' },
            { value: 'C', label: 'After 6 PM' },
            { value: 'D', label: 'On weekends only' },
          ],
          correctAnswer: 'C',
        },
      ],
    },
    {
      id: 'l1-s2',
      title: 'Section 2: Apartment Rental',
      description: 'A phone conversation about renting an apartment',
      audioText: `Hello, I'm calling about the apartment for rent on Queen Street. Is it still available? 

Yes, it is! It's a two-bedroom apartment on the third floor. The rent is £850 per month, plus utilities which average about £100. There's a security deposit of one month's rent required.

The apartment is furnished and includes a washing machine and dishwasher. Parking is available for an additional £50 per month. The building has an elevator and a shared garden area. The minimum lease term is six months, and pets are not allowed.

Would you like to schedule a viewing? We have slots available this Thursday at 2 PM or Friday at 10 AM.`,
      questions: [
        {
          id: 'l1-s2-q1',
          question: '4. How much is the monthly rent?',
          options: [
            { value: 'A', label: '£750' },
            { value: 'B', label: '£850' },
            { value: 'C', label: '£950' },
            { value: 'D', label: '£1050' },
          ],
          correctAnswer: 'B',
        },
        {
          id: 'l1-s2-q2',
          question: '5. How much do utilities typically cost per month?',
          options: [
            { value: 'A', label: '£50' },
            { value: 'B', label: '£75' },
            { value: 'C', label: '£100' },
            { value: 'D', label: '£125' },
          ],
          correctAnswer: 'C',
        },
        {
          id: 'l1-s2-q3',
          question: '6. What is the minimum lease term?',
          options: [
            { value: 'A', label: 'Three months' },
            { value: 'B', label: 'Six months' },
            { value: 'C', label: 'Nine months' },
            { value: 'D', label: 'Twelve months' },
          ],
          correctAnswer: 'B',
        },
      ],
    },
  ],
  // Listening Test Set 2
  [
    {
      id: 'l2-s1',
      title: 'Section 1: Hotel Reservation',
      description: 'A phone call about booking a hotel room',
      audioText: `Good morning, Grand Hotel. How may I help you?

I'd like to make a reservation for next weekend, please. I need a double room for two nights, checking in on Friday the 15th and checking out on Sunday the 17th.

Certainly. Let me check availability. Yes, we have rooms available. Our standard double room is £120 per night, or you can upgrade to a deluxe room with a sea view for £180 per night. Both rates include breakfast.

I'll take the standard room, please. Is there parking available?

Yes, parking is complimentary for all guests. We also offer free Wi-Fi throughout the hotel. Check-in time is from 3 PM, and checkout is by 11 AM.`,
      questions: [
        {
          id: 'l2-s1-q1',
          question: '1. When is the guest checking in?',
          options: [
            { value: 'A', label: 'Thursday the 14th' },
            { value: 'B', label: 'Friday the 15th' },
            { value: 'C', label: 'Saturday the 16th' },
            { value: 'D', label: 'Sunday the 17th' },
          ],
          correctAnswer: 'B',
        },
        {
          id: 'l2-s1-q2',
          question: '2. How much is the standard double room per night?',
          options: [
            { value: 'A', label: '£100' },
            { value: 'B', label: '£120' },
            { value: 'C', label: '£150' },
            { value: 'D', label: '£180' },
          ],
          correctAnswer: 'B',
        },
        {
          id: 'l2-s1-q3',
          question: '3. What is included in the room rate?',
          options: [
            { value: 'A', label: 'Breakfast only' },
            { value: 'B', label: 'Parking only' },
            { value: 'C', label: 'Breakfast and parking' },
            { value: 'D', label: 'All meals' },
          ],
          correctAnswer: 'A',
        },
      ],
    },
    {
      id: 'l2-s2',
      title: 'Section 2: Museum Tour',
      description: 'A guide explaining museum exhibitions',
      audioText: `Welcome to the National History Museum. Today's tour will last approximately 90 minutes and cover three main exhibitions.

We'll start with the Ancient Civilizations gallery on the ground floor, which features artifacts from Egypt, Greece, and Rome. This collection includes items dating back over 3,000 years. The highlight is a perfectly preserved Egyptian mummy discovered in 1922.

Next, we'll move to the second floor to see the Natural History exhibition. Here you'll find dinosaur skeletons, including a complete Tyrannosaurus Rex that's 67 million years old. We also have an interactive display about climate change.

Finally, we'll visit the Modern Art section on the third floor, which showcases works from the 20th and 21st centuries. Photography is not allowed in this area due to copyright restrictions. The museum shop is located near the exit and offers replicas of many exhibits.`,
      questions: [
        {
          id: 'l2-s2-q1',
          question: '4. How long will the tour last?',
          options: [
            { value: 'A', label: '60 minutes' },
            { value: 'B', label: '75 minutes' },
            { value: 'C', label: '90 minutes' },
            { value: 'D', label: '120 minutes' },
          ],
          correctAnswer: 'C',
        },
        {
          id: 'l2-s2-q2',
          question: '5. When was the Egyptian mummy discovered?',
          options: [
            { value: 'A', label: '1912' },
            { value: 'B', label: '1922' },
            { value: 'C', label: '1932' },
            { value: 'D', label: '1942' },
          ],
          correctAnswer: 'B',
        },
        {
          id: 'l2-s2-q3',
          question: '6. Where is photography not allowed?',
          options: [
            { value: 'A', label: 'Ancient Civilizations gallery' },
            { value: 'B', label: 'Natural History exhibition' },
            { value: 'C', label: 'Modern Art section' },
            { value: 'D', label: 'Museum shop' },
          ],
          correctAnswer: 'C',
        },
      ],
    },
  ],
  // Listening Test Set 3
  [
    {
      id: 'l3-s1',
      title: 'Section 1: Job Interview',
      description: 'A conversation about a job opportunity',
      audioText: `Thank you for coming in today. Let me tell you about the position. We're looking for a marketing assistant to join our team.

The role involves managing social media accounts, creating content for our website, and assisting with email campaigns. The salary range is £28,000 to £32,000 per year, depending on experience.

It's a full-time position, Monday to Friday, 9 AM to 5:30 PM, with a 30-minute lunch break. We offer 25 days of annual leave plus public holidays. There's also a pension scheme where the company contributes 5% if you contribute 3%.

The position is based in our London office, but we offer flexible working with the option to work from home two days per week. You'd be reporting directly to the Marketing Manager, and there's potential for career progression.`,
      questions: [
        {
          id: 'l3-s1-q1',
          question: '1. What is the position being offered?',
          options: [
            { value: 'A', label: 'Marketing Manager' },
            { value: 'B', label: 'Marketing Assistant' },
            { value: 'C', label: 'Social Media Manager' },
            { value: 'D', label: 'Content Creator' },
          ],
          correctAnswer: 'B',
        },
        {
          id: 'l3-s1-q2',
          question: '2. What is the maximum salary offered?',
          options: [
            { value: 'A', label: '£26,000' },
            { value: 'B', label: '£28,000' },
            { value: 'C', label: '£30,000' },
            { value: 'D', label: '£32,000' },
          ],
          correctAnswer: 'D',
        },
        {
          id: 'l3-s1-q3',
          question: '3. How many days of annual leave are offered?',
          options: [
            { value: 'A', label: '20 days' },
            { value: 'B', label: '22 days' },
            { value: 'C', label: '25 days' },
            { value: 'D', label: '28 days' },
          ],
          correctAnswer: 'C',
        },
      ],
    },
    {
      id: 'l3-s2',
      title: 'Section 2: Cooking Class',
      description: 'An instructor explaining a cooking course',
      audioText: `Welcome to our Italian Cooking Masterclass. This six-week course will teach you how to prepare authentic Italian dishes from scratch.

Classes are held every Tuesday evening from 6:30 PM to 9 PM in our professional kitchen. The course fee is £240, which includes all ingredients and a recipe booklet. You'll need to bring your own apron and containers to take home your creations.

In week one, we'll focus on making fresh pasta, including tagliatelle and ravioli. Week two covers classic sauces like carbonara and amatriciana. Weeks three and four are dedicated to risotto and pizza-making techniques. In week five, we'll explore Italian desserts, including tiramisu and panna cotta. The final week is a celebration dinner where you'll prepare a complete three-course meal.

Class size is limited to 12 participants to ensure everyone gets personal attention. If you need to miss a class, you can join the same session in the next course cycle at no extra cost.`,
      questions: [
        {
          id: 'l3-s2-q1',
          question: '4. How long is the cooking course?',
          options: [
            { value: 'A', label: 'Four weeks' },
            { value: 'B', label: 'Five weeks' },
            { value: 'C', label: 'Six weeks' },
            { value: 'D', label: 'Eight weeks' },
          ],
          correctAnswer: 'C',
        },
        {
          id: 'l3-s2-q2',
          question: '5. What is the course fee?',
          options: [
            { value: 'A', label: '£200' },
            { value: 'B', label: '£220' },
            { value: 'C', label: '£240' },
            { value: 'D', label: '£260' },
          ],
          correctAnswer: 'C',
        },
        {
          id: 'l3-s2-q3',
          question: '6. What is the maximum class size?',
          options: [
            { value: 'A', label: '8 participants' },
            { value: 'B', label: '10 participants' },
            { value: 'C', label: '12 participants' },
            { value: 'D', label: '15 participants' },
          ],
          correctAnswer: 'C',
        },
      ],
    },
  ],
];

// WRITING TASKS (2 tasks per test)
export const writingTasks: WritingTask[][] = [
  // Writing Test Set 1
  [
    {
      id: 'w1-t1',
      taskNumber: 1,
      title: 'Writing Task 1',
      instruction: 'The chart below shows the percentage of households in different countries that owned various electronic devices in 2020. Summarize the information by selecting and reporting the main features, and make comparisons where relevant.',
      minWords: 150,
    },
    {
      id: 'w1-t2',
      taskNumber: 2,
      title: 'Writing Task 2',
      instruction: 'Some people believe that universities should focus on providing academic skills, while others think they should prepare students for their future careers. Discuss both views and give your own opinion.',
      minWords: 250,
    },
  ],
  // Writing Test Set 2
  [
    {
      id: 'w2-t1',
      taskNumber: 1,
      title: 'Writing Task 1',
      instruction: 'The graph below shows the number of tourists visiting a particular Caribbean island between 2010 and 2020. Summarize the information by selecting and reporting the main features, and make comparisons where relevant.',
      minWords: 150,
    },
    {
      id: 'w2-t2',
      taskNumber: 2,
      title: 'Writing Task 2',
      instruction: 'Many people believe that social media sites such as Facebook have had a huge negative impact on both individuals and society. To what extent do you agree or disagree?',
      minWords: 250,
    },
  ],
  // Writing Test Set 3
  [
    {
      id: 'w3-t1',
      taskNumber: 1,
      title: 'Writing Task 1',
      instruction: 'The diagram below shows the process of recycling plastic bottles. Summarize the information by selecting and reporting the main features.',
      minWords: 150,
    },
    {
      id: 'w3-t2',
      taskNumber: 2,
      title: 'Writing Task 2',
      instruction: 'Some people think that parents should teach children how to be good members of society. Others believe that school is the place to learn this. Discuss both views and give your own opinion.',
      minWords: 250,
    },
  ],
];

// SPEAKING PARTS (3 parts per test)
export const speakingParts: SpeakingPart[][] = [
  // Speaking Test Set 1
  [
    {
      id: 's1-p1',
      partNumber: 1,
      title: 'Part 1: Introduction and Interview',
      description: 'Answer questions about yourself and familiar topics',
      question: 'Let\'s talk about your hometown. Where is your hometown? What do you like most about it? Has it changed much since you were a child?',
    },
    {
      id: 's1-p2',
      partNumber: 2,
      title: 'Part 2: Individual Long Turn',
      description: 'Speak for 1-2 minutes on this topic',
      question: 'Describe a book that you have read recently. You should say: what the book was about, why you chose to read it, what you learned from it, and explain whether you would recommend it to others.',
    },
    {
      id: 's1-p3',
      partNumber: 3,
      title: 'Part 3: Two-way Discussion',
      description: 'Discuss this topic in depth',
      question: 'How do you think reading habits have changed in recent years? What impact has technology had on the way people read? Do you think physical books will disappear in the future?',
    },
  ],
  // Speaking Test Set 2
  [
    {
      id: 's2-p1',
      partNumber: 1,
      title: 'Part 1: Introduction and Interview',
      description: 'Answer questions about yourself and familiar topics',
      question: 'Let\'s talk about your daily routine. What time do you usually wake up? What do you typically do in the evenings? Do you prefer mornings or evenings?',
    },
    {
      id: 's2-p2',
      partNumber: 2,
      title: 'Part 2: Individual Long Turn',
      description: 'Speak for 1-2 minutes on this topic',
      question: 'Describe a person who has influenced you. You should say: who this person is, how you know them, what qualities they have, and explain why they have influenced you.',
    },
    {
      id: 's2-p3',
      partNumber: 3,
      title: 'Part 3: Two-way Discussion',
      description: 'Discuss this topic in depth',
      question: 'Do you think role models are important in society? How has the concept of role models changed with social media? What makes someone a good role model?',
    },
  ],
  // Speaking Test Set 3
  [
    {
      id: 's3-p1',
      partNumber: 1,
      title: 'Part 1: Introduction and Interview',
      description: 'Answer questions about yourself and familiar topics',
      question: 'Let\'s talk about food. What is your favorite type of food? Do you enjoy cooking? Have your food preferences changed over time?',
    },
    {
      id: 's3-p2',
      partNumber: 2,
      title: 'Part 2: Individual Long Turn',
      description: 'Speak for 1-2 minutes on this topic',
      question: 'Describe a memorable journey you have taken. You should say: where you went, who you went with, what you did there, and explain why it was memorable.',
    },
    {
      id: 's3-p3',
      partNumber: 3,
      title: 'Part 3: Two-way Discussion',
      description: 'Discuss this topic in depth',
      question: 'How has tourism changed in your country over the years? What are the positive and negative impacts of tourism? Do you think sustainable tourism is achievable?',
    },
  ],
];

// Function to get a random test set
export function getRandomTestSet() {
  const readingIndex = Math.floor(Math.random() * readingPassages.length);
  const listeningIndex = Math.floor(Math.random() * listeningSections.length);
  const writingIndex = Math.floor(Math.random() * writingTasks.length);
  const speakingIndex = Math.floor(Math.random() * speakingParts.length);

  return {
    reading: readingPassages[readingIndex],
    listening: listeningSections[listeningIndex],
    writing: writingTasks[writingIndex],
    speaking: speakingParts[speakingIndex],
    testId: `test-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
  };
}
