import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import { Award, BookOpen, Headphones, Pencil, Mic, TrendingUp, RefreshCw, Home } from 'lucide-react';
import type { TestResults } from '../App';

interface ResultsPageProps {
  results: TestResults;
  onRetakeTest: () => void;
  onGoHome: () => void;
}

export function ResultsPage({ results, onRetakeTest, onGoHome }: ResultsPageProps) {
  const getBandColor = (band: number) => {
    if (band >= 8) return 'text-green-600';
    if (band >= 6.5) return 'text-blue-600';
    if (band >= 5) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getBandFeedback = (band: number) => {
    if (band >= 8) return 'Excellent! Very good user of the language.';
    if (band >= 7) return 'Good! Competent user with occasional inaccuracies.';
    if (band >= 6) return 'Competent! Generally effective command of the language.';
    if (band >= 5) return 'Modest! Partial command with likely mistakes.';
    return 'Limited! Basic competence in familiar situations only.';
  };

  const sections = [
    {
      title: 'Reading',
      icon: BookOpen,
      color: 'bg-blue-100 text-blue-600',
      data: results.reading,
    },
    {
      title: 'Listening',
      icon: Headphones,
      color: 'bg-green-100 text-green-600',
      data: results.listening,
    },
    {
      title: 'Writing',
      icon: Pencil,
      color: 'bg-purple-100 text-purple-600',
      data: results.writing,
    },
    {
      title: 'Speaking',
      icon: Mic,
      color: 'bg-orange-100 text-orange-600',
      data: results.speaking,
    },
  ];

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <h1 className="text-indigo-600">Your IELTS Test Results</h1>
            <div className="flex gap-3">
              <Button variant="outline" onClick={onGoHome}>
                <Home className="w-4 h-4 mr-2" />
                Home
              </Button>
              <Button onClick={onRetakeTest}>
                <RefreshCw className="w-4 h-4 mr-2" />
                Retake Test
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12">
        {/* Overall Score */}
        <div className="mb-12">
          <Card className="border-2 border-indigo-600">
            <CardContent className="pt-6">
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-32 h-32 bg-indigo-600 rounded-full mb-4">
                  <div className="text-center">
                    <div className="text-white">Overall</div>
                    <div className="text-white">{results.overall}</div>
                  </div>
                </div>
                <h2 className="text-gray-900 mb-2">Your IELTS Band Score</h2>
                <p className="text-gray-600 mb-4">{getBandFeedback(results.overall)}</p>
                <div className="flex items-center justify-center gap-2">
                  <Award className="w-5 h-5 text-indigo-600" />
                  <span className={getBandColor(results.overall)}>
                    Band {results.overall}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Section Breakdown */}
        <div className="mb-12">
          <h2 className="text-gray-900 mb-6 text-center">Section Breakdown</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {sections.map((section) => {
              const Icon = section.icon;
              const percentage = (section.data.score / section.data.total) * 100;
              
              return (
                <Card key={section.title}>
                  <CardHeader>
                    <div className={`w-12 h-12 ${section.color} rounded-lg flex items-center justify-center mb-4`}>
                      <Icon className="w-6 h-6" />
                    </div>
                    <CardTitle>{section.title}</CardTitle>
                    <CardDescription>
                      {section.data.score} / {section.data.total} correct
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <Progress value={percentage} className="h-2" />
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">Band Score</span>
                        <span className={`${getBandColor(section.data.band)}`}>
                          {section.data.band}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600">
                        {percentage.toFixed(0)}% accuracy
                      </p>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Performance Insights */}
        <div className="mb-12">
          <h2 className="text-gray-900 mb-6 text-center">Performance Insights</h2>
          <div className="grid md:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                  <TrendingUp className="w-6 h-6 text-green-600" />
                </div>
                <CardTitle>Strengths</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-gray-600">
                  {results.reading.band >= results.listening.band && results.reading.band >= results.writing.band ? (
                    <li>• Strong reading comprehension skills</li>
                  ) : null}
                  {results.listening.band >= 7 ? (
                    <li>• Excellent listening ability</li>
                  ) : null}
                  {results.overall >= 6.5 ? (
                    <li>• Good overall English proficiency</li>
                  ) : null}
                  {!results.reading.band && !results.listening.band && !results.overall ? (
                    <li>• Complete the test to see your strengths</li>
                  ) : null}
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center mb-4">
                  <Award className="w-6 h-6 text-yellow-600" />
                </div>
                <CardTitle>Areas to Improve</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-gray-600">
                  {results.writing.band < 6 ? (
                    <li>• Focus on writing practice</li>
                  ) : null}
                  {results.speaking.band < 6 ? (
                    <li>• Work on speaking fluency</li>
                  ) : null}
                  {results.listening.band < results.reading.band - 1 ? (
                    <li>• Practice listening comprehension</li>
                  ) : null}
                  {results.writing.band >= 6 && results.speaking.band >= 6 ? (
                    <li>• Continue consistent practice</li>
                  ) : null}
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                  <BookOpen className="w-6 h-6 text-blue-600" />
                </div>
                <CardTitle>Recommendations</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-gray-600">
                  <li>• Take regular practice tests</li>
                  <li>• Read academic articles daily</li>
                  <li>• Practice writing essays weekly</li>
                  <li>• Engage in English conversations</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Band Score Guide */}
        <Card>
          <CardHeader>
            <CardTitle>IELTS Band Score Guide</CardTitle>
            <CardDescription>Understanding your score</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <span className="text-green-600">9-8</span>
                  </div>
                  <div>
                    <p className="text-sm">Expert / Very Good User</p>
                    <p className="text-sm text-gray-600">Full operational command of the language</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <span className="text-blue-600">7-6.5</span>
                  </div>
                  <div>
                    <p className="text-sm">Good / Competent User</p>
                    <p className="text-sm text-gray-600">Effective command with occasional inaccuracies</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <span className="text-yellow-600">6-5.5</span>
                  </div>
                  <div>
                    <p className="text-sm">Competent / Modest User</p>
                    <p className="text-sm text-gray-600">Generally effective command in familiar situations</p>
                  </div>
                </div>
              </div>
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <span className="text-orange-600">5-4.5</span>
                  </div>
                  <div>
                    <p className="text-sm">Modest / Limited User</p>
                    <p className="text-sm text-gray-600">Partial command with frequent problems</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <span className="text-red-600">4-0</span>
                  </div>
                  <div>
                    <p className="text-sm">Limited / Non User</p>
                    <p className="text-sm text-gray-600">Basic competence limited to familiar situations</p>
                  </div>
                </div>
                <div className="p-4 bg-indigo-50 rounded-lg">
                  <p className="text-sm text-indigo-900">
                    Most universities require a minimum band score of 6.0-7.0 for admission.
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="mt-12 text-center space-x-4">
          <Button onClick={onRetakeTest} size="lg">
            <RefreshCw className="w-4 h-4 mr-2" />
            Take Another Practice Test
          </Button>
          <Button variant="outline" size="lg" onClick={onGoHome}>
            Return to Home
          </Button>
        </div>
      </main>
    </div>
  );
}
