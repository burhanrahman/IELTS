import { useState, useEffect, useRef } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Clock, BookOpen, Headphones, Pencil, Mic, AlertCircle, Play, Pause, RotateCcw, Volume2, ChevronRight, ChevronLeft } from 'lucide-react';
import { Alert, AlertDescription } from './ui/alert';
import type { TestAnswers, TestSet } from '../App';

interface TestInterfaceProps {
  testSet: TestSet;
  onSubmit: (answers: TestAnswers) => void;
  onCancel: () => void;
}

export function TestInterface({ testSet, onSubmit, onCancel }: TestInterfaceProps) {
  const [answers, setAnswers] = useState<TestAnswers>({
    reading: {},
    listening: {},
    writing: {},
    speaking: {},
  });
  const [timeLeft, setTimeLeft] = useState(60 * 60); // 60 minutes
  const [currentTab, setCurrentTab] = useState('reading');
  const [currentListeningSection, setCurrentListeningSection] = useState(0);
  const [isAudioPlaying, setIsAudioPlaying] = useState(false);
  const [audioProgress, setAudioProgress] = useState(0);
  const [voicesLoaded, setVoicesLoaded] = useState(false);
  const speechRef = useRef<SpeechSynthesisUtterance | null>(null);
  const progressIntervalRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          handleSubmit();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    // Load voices for text-to-speech
    const loadVoices = () => {
      const voices = window.speechSynthesis.getVoices();
      if (voices.length > 0) {
        setVoicesLoaded(true);
      }
    };

    if (window.speechSynthesis.onvoiceschanged !== undefined) {
      window.speechSynthesis.onvoiceschanged = loadVoices;
    }
    loadVoices();

    return () => {
      clearInterval(timer);
      stopAudio();
    };
  }, []);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleAnswerChange = (section: keyof TestAnswers, questionId: string, value: string) => {
    setAnswers((prev) => ({
      ...prev,
      [section]: {
        ...prev[section],
        [questionId]: value,
      },
    }));
  };

  const calculateProgress = () => {
    const totalReadingQuestions = testSet.reading.reduce((sum, passage) => sum + passage.questions.length, 0);
    const totalListeningQuestions = testSet.listening.reduce((sum, section) => sum + section.questions.length, 0);
    const totalQuestions = totalReadingQuestions + totalListeningQuestions + testSet.writing.length + testSet.speaking.length;
    
    const answeredQuestions = 
      Object.keys(answers.reading).length +
      Object.keys(answers.listening).length +
      Object.keys(answers.writing).length +
      Object.keys(answers.speaking).length;
    
    return (answeredQuestions / totalQuestions) * 100;
  };

  const handleSubmit = () => {
    stopAudio();
    onSubmit(answers);
  };

  const goToSection = (section: string) => {
    setCurrentTab(section);
    // Scroll to top of page
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Audio functions
  const getBritishVoice = () => {
    const voices = window.speechSynthesis.getVoices();
    
    // Priority 1: Look for premium/natural British voices
    const premiumBritish = voices.find(voice => 
      (voice.lang === 'en-GB' || voice.lang.startsWith('en-GB')) &&
      (voice.name.toLowerCase().includes('natural') ||
       voice.name.toLowerCase().includes('premium') ||
       voice.name.toLowerCase().includes('enhanced'))
    );
    if (premiumBritish) return premiumBritish;
    
    // Priority 2: British English voices
    const britishVoices = voices.filter(voice => 
      voice.lang === 'en-GB' || voice.lang.startsWith('en-GB')
    );
    
    // Priority 3: Specific high-quality British voices (Google, Microsoft, Apple)
    const qualityVoiceNames = ['daniel', 'kate', 'serena', 'victoria', 'hazel', 'oliver', 'google uk english', 'microsoft'];
    const qualityBritish = britishVoices.find(voice => 
      qualityVoiceNames.some(name => voice.name.toLowerCase().includes(name))
    );
    if (qualityBritish) return qualityBritish;
    
    // Priority 4: Female British voices (typically clearer)
    const femaleBritish = britishVoices.find(voice => 
      voice.name.toLowerCase().includes('female') || 
      voice.name.toLowerCase().includes('woman')
    );
    if (femaleBritish) return femaleBritish;
    
    // Priority 5: Any British voice
    if (britishVoices.length > 0) return britishVoices[0];
    
    // Priority 6: UK variations
    const ukVoice = voices.find(voice => 
      voice.lang.includes('GB') || 
      voice.name.toLowerCase().includes('british') ||
      voice.name.toLowerCase().includes('uk')
    );
    if (ukVoice) return ukVoice;
    
    // Fallback: Any English voice
    const englishVoice = voices.find(voice => voice.lang.startsWith('en'));
    return englishVoice || voices[0];
  };

  const getVoiceQuality = () => {
    const voice = getBritishVoice();
    if (!voice) return 'basic';
    
    const name = voice.name.toLowerCase();
    if (name.includes('google') || name.includes('natural') || name.includes('premium') || name.includes('enhanced')) {
      return 'high';
    }
    if (name.includes('microsoft') || name.includes('apple')) {
      return 'good';
    }
    return 'basic';
  };

  const playAudio = (sectionIndex: number) => {
    if ('speechSynthesis' in window) {
      stopAudio();
      
      // Add natural pauses and formatting to the text
      const audioText = testSet.listening[sectionIndex].audioText
        .replace(/\n\n/g, '... ') // Add pauses between paragraphs
        .replace(/\. /g, '. ... ') // Add slight pauses after sentences
        .replace(/\, /g, ', . '); // Add micro pauses after commas
      
      const utterance = new SpeechSynthesisUtterance(audioText);
      
      const britishVoice = getBritishVoice();
      if (britishVoice) {
        utterance.voice = britishVoice;
      }
      
      // More natural speech parameters
      utterance.rate = 0.9; // Slightly faster for more natural flow
      utterance.pitch = 1.05; // Slightly higher pitch for clearer female voice
      utterance.volume = 1;
      utterance.lang = 'en-GB';
      
      utterance.onstart = () => {
        setIsAudioPlaying(true);
        setAudioProgress(0);
        
        const duration = (audioText.length / 15) * 1000;
        const interval = 100;
        let elapsed = 0;
        
        progressIntervalRef.current = setInterval(() => {
          elapsed += interval;
          const progress = Math.min((elapsed / duration) * 100, 100);
          setAudioProgress(progress);
          
          if (progress >= 100 && progressIntervalRef.current) {
            clearInterval(progressIntervalRef.current);
          }
        }, interval);
      };
      
      utterance.onend = () => {
        setIsAudioPlaying(false);
        setAudioProgress(100);
        if (progressIntervalRef.current) {
          clearInterval(progressIntervalRef.current);
        }
      };
      
      utterance.onerror = () => {
        setIsAudioPlaying(false);
        setAudioProgress(0);
        if (progressIntervalRef.current) {
          clearInterval(progressIntervalRef.current);
        }
      };
      
      speechRef.current = utterance;
      window.speechSynthesis.speak(utterance);
    }
  };

  const pauseAudio = () => {
    if (window.speechSynthesis.speaking) {
      window.speechSynthesis.pause();
      setIsAudioPlaying(false);
      if (progressIntervalRef.current) {
        clearInterval(progressIntervalRef.current);
      }
    }
  };

  const resumeAudio = () => {
    if (window.speechSynthesis.paused) {
      window.speechSynthesis.resume();
      setIsAudioPlaying(true);
    } else {
      playAudio(currentListeningSection);
    }
  };

  const stopAudio = () => {
    if (window.speechSynthesis.speaking) {
      window.speechSynthesis.cancel();
    }
    setIsAudioPlaying(false);
    setAudioProgress(0);
    if (progressIntervalRef.current) {
      clearInterval(progressIntervalRef.current);
    }
  };

  const replayAudio = () => {
    stopAudio();
    setTimeout(() => playAudio(currentListeningSection), 100);
  };

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-indigo-600">IELTS Practice Test</h1>
              <p className="text-sm text-gray-600">Test ID: {testSet.testId.slice(0, 12)}...</p>
            </div>
            <div className="flex items-center gap-6">
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-gray-600" />
                <span className={timeLeft < 300 ? 'text-red-600' : 'text-gray-900'}>
                  {formatTime(timeLeft)}
                </span>
              </div>
              <Button variant="outline" onClick={onCancel}>
                Exit Test
              </Button>
              <Button onClick={handleSubmit}>
                Submit Test
              </Button>
            </div>
          </div>
          <div className="mt-4">
            <Progress value={calculateProgress()} className="h-2" />
            <p className="text-sm text-gray-600 mt-2">
              {Math.round(calculateProgress())}% Complete
            </p>
          </div>
        </div>
      </header>

      {/* Test Content */}
      <main className="container mx-auto px-4 py-8">
        <Tabs value={currentTab} onValueChange={(value) => {
          setCurrentTab(value);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}>
          <TabsList className="grid w-full grid-cols-4 mb-8">
            <TabsTrigger value="reading" className="flex items-center gap-2">
              <BookOpen className="w-4 h-4" />
              Reading
            </TabsTrigger>
            <TabsTrigger value="listening" className="flex items-center gap-2">
              <Headphones className="w-4 h-4" />
              Listening
            </TabsTrigger>
            <TabsTrigger value="writing" className="flex items-center gap-2">
              <Pencil className="w-4 h-4" />
              Writing
            </TabsTrigger>
            <TabsTrigger value="speaking" className="flex items-center gap-2">
              <Mic className="w-4 h-4" />
              Speaking
            </TabsTrigger>
          </TabsList>

          {/* Reading Section */}
          <TabsContent value="reading">
            <div className="space-y-8">
              {testSet.reading.map((passage, passageIndex) => (
                <Card key={passage.id}>
                  <CardHeader>
                    <CardTitle>Passage {passageIndex + 1}: {passage.title}</CardTitle>
                    <CardDescription>Read the passage and answer the questions below</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="bg-gray-50 p-6 rounded-lg">
                      <div className="space-y-4 text-gray-700">
                        {passage.content.map((paragraph, idx) => (
                          <p key={idx}>{paragraph}</p>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-6">
                      {passage.questions.map((q) => (
                        <div key={q.id} className="border-l-4 border-indigo-600 pl-4 py-2">
                          <p className="mb-4">{q.question}</p>
                          <RadioGroup
                            value={answers.reading[q.id] || ''}
                            onValueChange={(value) => handleAnswerChange('reading', q.id, value)}
                          >
                            {q.options.map((option, index) => (
                              <div key={index} className="flex items-center space-x-3 mb-3 p-3 rounded-lg hover:bg-indigo-50 transition-colors cursor-pointer">
                                <RadioGroupItem value={option.value} id={`${q.id}-${option.value}`} />
                                <Label htmlFor={`${q.id}-${option.value}`} className="cursor-pointer flex-1">{option.label}</Label>
                              </div>
                            ))}
                          </RadioGroup>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
              
              {/* Next Section Button */}
              <div className="flex justify-end">
                <Button onClick={() => goToSection('listening')} size="lg" className="mt-4">
                  Next: Listening Section
                  <ChevronRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </div>
          </TabsContent>

          {/* Listening Section */}
          <TabsContent value="listening">
            <div className="space-y-6">
              {/* Section Navigation */}
              <div className="flex items-center justify-between bg-white p-4 rounded-lg shadow-sm">
                <Button
                  variant="outline"
                  onClick={() => {
                    stopAudio();
                    setCurrentListeningSection(Math.max(0, currentListeningSection - 1));
                  }}
                  disabled={currentListeningSection === 0}
                >
                  <ChevronLeft className="w-4 h-4 mr-2" />
                  Previous
                </Button>
                <span className="text-gray-700">
                  Listening Section {currentListeningSection + 1} of {testSet.listening.length}
                </span>
                <Button
                  variant="outline"
                  onClick={() => {
                    stopAudio();
                    setCurrentListeningSection(Math.min(testSet.listening.length - 1, currentListeningSection + 1));
                  }}
                  disabled={currentListeningSection === testSet.listening.length - 1}
                >
                  Next
                  <ChevronRight className="w-4 h-4 ml-2" />
                </Button>
              </div>

              {/* Current Listening Section */}
              {testSet.listening[currentListeningSection] && (
                <Card>
                  <CardHeader>
                    <CardTitle>{testSet.listening[currentListeningSection].title}</CardTitle>
                    <CardDescription>{testSet.listening[currentListeningSection].description}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Audio Player */}
                    <div className="bg-gradient-to-r from-green-50 to-emerald-50 p-6 rounded-lg border-2 border-green-200">
                      <div className="flex items-center gap-3 mb-4">
                        <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center">
                          <Volume2 className="w-6 h-6 text-white" />
                        </div>
                        <div className="flex-1">
                          <h3 className="text-green-900">Audio Recording</h3>
                          <p className="text-sm text-green-700">Listen carefully and answer the questions below</p>
                          {voicesLoaded && (
                            <div className="mt-1 space-y-1">
                              <p className="text-xs text-green-600">
                                🇬🇧 British English voice - {getBritishVoice()?.name || 'Default'}
                              </p>
                              {getVoiceQuality() === 'basic' && (
                                <p className="text-xs text-amber-600">
                                  ⚠️ Using basic voice. For better quality, use Chrome/Edge on Windows or Safari on Mac
                                </p>
                              )}
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Audio Controls */}
                      <div className="space-y-4">
                        <div className="flex items-center gap-3">
                          {!isAudioPlaying && audioProgress === 0 && (
                            <Button onClick={() => playAudio(currentListeningSection)} className="bg-green-600 hover:bg-green-700">
                              <Play className="w-4 h-4 mr-2" />
                              Play Audio
                            </Button>
                          )}
                          
                          {isAudioPlaying && (
                            <Button onClick={pauseAudio} variant="outline">
                              <Pause className="w-4 h-4 mr-2" />
                              Pause
                            </Button>
                          )}
                          
                          {!isAudioPlaying && audioProgress > 0 && audioProgress < 100 && (
                            <Button onClick={resumeAudio} className="bg-green-600 hover:bg-green-700">
                              <Play className="w-4 h-4 mr-2" />
                              Resume
                            </Button>
                          )}
                          
                          <Button onClick={replayAudio} variant="outline">
                            <RotateCcw className="w-4 h-4 mr-2" />
                            Replay
                          </Button>
                          
                          {isAudioPlaying && (
                            <span className="text-sm text-green-700 flex items-center gap-2">
                              <span className="w-2 h-2 bg-green-600 rounded-full animate-pulse"></span>
                              Playing...
                            </span>
                          )}
                        </div>

                        <div className="space-y-2">
                          <Progress value={audioProgress} className="h-2 bg-green-200" />
                          <p className="text-xs text-green-700">
                            {audioProgress < 100 ? `${Math.round(audioProgress)}% complete` : 'Audio finished'}
                          </p>
                        </div>
                      </div>

                      <div className="mt-4 space-y-2">
                        <Alert className="bg-green-100 border-green-300">
                          <AlertCircle className="h-4 w-4 text-green-700" />
                          <AlertDescription className="text-green-800">
                            You can replay the audio as many times as needed. In the actual IELTS test, you typically hear the recording only once or twice.
                          </AlertDescription>
                        </Alert>
                        
                        <details className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                          <summary className="cursor-pointer text-sm text-blue-900 hover:text-blue-700">
                            💡 How to get better voice quality
                          </summary>
                          <div className="mt-2 text-xs text-blue-800 space-y-2">
                            <p><strong>For best audio quality:</strong></p>
                            <ul className="list-disc list-inside space-y-1 ml-2">
                              <li><strong>Chrome/Edge (Windows):</strong> Automatically uses Microsoft natural voices</li>
                              <li><strong>Safari (Mac):</strong> Uses high-quality Apple voices like "Daniel" (UK)</li>
                              <li><strong>Chrome (Mac):</strong> Install additional voices in System Preferences → Accessibility → Spoken Content</li>
                              <li><strong>Alternative:</strong> You can mute the audio and read the transcript aloud yourself</li>
                            </ul>
                            <p className="pt-2 border-t border-blue-300">
                              <strong>Note:</strong> In a production app, we would use premium TTS APIs like Google Cloud Text-to-Speech or ElevenLabs for realistic voices, but those require API keys and incur costs.
                            </p>
                          </div>
                        </details>
                      </div>
                    </div>

                    {/* Transcript (Optional) */}
                    <details className="bg-gray-50 p-4 rounded-lg">
                      <summary className="cursor-pointer text-gray-700 hover:text-gray-900">
                        Show Transcript (for reference)
                      </summary>
                      <div className="mt-4 text-gray-700 whitespace-pre-line">
                        {testSet.listening[currentListeningSection].audioText}
                      </div>
                    </details>

                    {/* Questions */}
                    <div className="space-y-6">
                      {testSet.listening[currentListeningSection].questions.map((q) => (
                        <div key={q.id} className="border-l-4 border-green-600 pl-4 py-2">
                          <p className="mb-4">{q.question}</p>
                          <RadioGroup
                            value={answers.listening[q.id] || ''}
                            onValueChange={(value) => handleAnswerChange('listening', q.id, value)}
                          >
                            {q.options.map((option, index) => (
                              <div key={index} className="flex items-center space-x-3 mb-3 p-3 rounded-lg hover:bg-green-50 transition-colors cursor-pointer">
                                <RadioGroupItem value={option.value} id={`${q.id}-${option.value}`} />
                                <Label htmlFor={`${q.id}-${option.value}`} className="cursor-pointer flex-1">{option.label}</Label>
                              </div>
                            ))}
                          </RadioGroup>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
              
              {/* Next Section Button */}
              <div className="flex justify-end">
                <Button onClick={() => goToSection('writing')} size="lg" className="mt-4">
                  Next: Writing Section
                  <ChevronRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </div>
          </TabsContent>

          {/* Writing Section */}
          <TabsContent value="writing">
            <div className="space-y-6">
              {testSet.writing.map((task) => (
                <Card key={task.id}>
                  <CardHeader>
                    <CardTitle>{task.title}</CardTitle>
                    <CardDescription>Write at least {task.minWords} words</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="mb-4 text-gray-700">{task.instruction}</p>
                    <Textarea
                      placeholder="Write your response here..."
                      className="min-h-[250px]"
                      value={answers.writing[task.id] || ''}
                      onChange={(e) => handleAnswerChange('writing', task.id, e.target.value)}
                    />
                    <p className="text-sm text-gray-600 mt-2">
                      Word count: {(answers.writing[task.id] || '').split(/\s+/).filter(Boolean).length} / {task.minWords} minimum
                    </p>
                  </CardContent>
                </Card>
              ))}
              
              {/* Next Section Button */}
              <div className="flex justify-end">
                <Button onClick={() => goToSection('speaking')} size="lg" className="mt-4">
                  Next: Speaking Section
                  <ChevronRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </div>
          </TabsContent>

          {/* Speaking Section */}
          <TabsContent value="speaking">
            <div className="space-y-6">
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  In a real test, you would speak your answers to an examiner. For this practice, type your responses.
                </AlertDescription>
              </Alert>

              {testSet.speaking.map((part) => (
                <Card key={part.id}>
                  <CardHeader>
                    <CardTitle>{part.title}</CardTitle>
                    <CardDescription>{part.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="mb-4 text-gray-700">{part.question}</p>
                    <Textarea
                      placeholder="Type your response here..."
                      className="min-h-[150px]"
                      value={answers.speaking[part.id] || ''}
                      onChange={(e) => handleAnswerChange('speaking', part.id, e.target.value)}
                    />
                    <p className="text-sm text-gray-600 mt-2">
                      Word count: {(answers.speaking[part.id] || '').split(/\s+/).filter(Boolean).length}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>

        <div className="mt-8 flex justify-between">
          <Button variant="outline" onClick={onCancel}>
            Save & Exit
          </Button>
          <Button onClick={handleSubmit} size="lg">
            Submit Test for Grading
          </Button>
        </div>
      </main>
    </div>
  );
}
