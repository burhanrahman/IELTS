import { BookOpen, Headphones, Pencil, Mic, Clock, Award, TrendingUp } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';

interface HomePageProps {
  onStartTest: () => void;
}

export function HomePage({ onStartTest }: HomePageProps) {
  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-indigo-600 rounded-lg flex items-center justify-center">
                <Award className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-indigo-600">IELTS Master</h1>
                <p className="text-sm text-gray-600">Practice & Ace Your Test</p>
              </div>
            </div>
            <Button onClick={onStartTest} size="lg">
              Start Practice Test
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-16">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-gray-900 mb-4">Master Your IELTS Exam</h2>
          <p className="text-gray-600 mb-8">
            Take full-length practice tests with instant results and detailed feedback. 
            Improve your Reading, Listening, Writing, and Speaking skills with our comprehensive platform.
          </p>
          <Button onClick={onStartTest} size="lg" className="mr-4">
            Take Practice Test Now
          </Button>
          <Button variant="outline" size="lg">
            Learn About IELTS
          </Button>
        </div>

        {/* Test Sections */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          <Card>
            <CardHeader>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                <BookOpen className="w-6 h-6 text-blue-600" />
              </div>
              <CardTitle>Reading</CardTitle>
              <CardDescription>2 Passages, 10 Questions</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600">
                Test your comprehension with academic passages covering diverse topics. Each test has different content!
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                <Headphones className="w-6 h-6 text-green-600" />
              </div>
              <CardTitle>Listening</CardTitle>
              <CardDescription>2 Sections, 6 Questions</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600">
                Listen to British English audio recordings and answer questions. New scenarios every time!
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
                <Pencil className="w-6 h-6 text-purple-600" />
              </div>
              <CardTitle>Writing</CardTitle>
              <CardDescription>2 Tasks</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600">
                Task 1: Describe data or processes. Task 2: Write an academic essay on various topics.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mb-4">
                <Mic className="w-6 h-6 text-orange-600" />
              </div>
              <CardTitle>Speaking</CardTitle>
              <CardDescription>3 Parts</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600">
                Part 1: Personal questions. Part 2: Individual long turn. Part 3: Discussion on abstract topics.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Features */}
        <div className="grid md:grid-cols-3 gap-8 mb-16">
          <div className="text-center">
            <div className="w-16 h-16 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Clock className="w-8 h-8 text-indigo-600" />
            </div>
            <h3 className="mb-2">Instant Results</h3>
            <p className="text-gray-600">
              Get your band scores immediately after completing the test
            </p>
          </div>

          <div className="text-center">
            <div className="w-16 h-16 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <TrendingUp className="w-8 h-8 text-indigo-600" />
            </div>
            <h3 className="mb-2">Dynamic Content</h3>
            <p className="text-gray-600">
              Every test has different questions - practice with fresh material each time
            </p>
          </div>

          <div className="text-center">
            <div className="w-16 h-16 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Award className="w-8 h-8 text-indigo-600" />
            </div>
            <h3 className="mb-2">Realistic Practice</h3>
            <p className="text-gray-600">
              British English audio and authentic IELTS-style questions
            </p>
          </div>
        </div>

        {/* CTA */}
        <div className="bg-indigo-600 rounded-2xl p-12 text-center text-white">
          <h2 className="mb-4">Ready to Test Your English Skills?</h2>
          <p className="mb-8 text-indigo-100">
            Start your practice test now and discover your IELTS band score in minutes
          </p>
          <Button onClick={onStartTest} size="lg" variant="secondary">
            Begin Practice Test
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white border-t mt-16">
        <div className="container mx-auto px-4 py-8">
          <p className="text-center text-gray-600">
            © 2025 IELTS Master. Practice tests for educational purposes.
          </p>
        </div>
      </footer>
    </div>
  );
}
